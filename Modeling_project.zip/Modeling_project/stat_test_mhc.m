% doing t-test to test 
% 1: if percentage of the wound contain debris is significantly different
% between healthy person and Leukopenia patient for each type of bacteria(differrent proliferation rate)
% 2: if percentage of the bacteria been eaten is significantly different
% between healthy person and Leukopenia patient for each type of bacteria(differrent proliferation rate)
clc; clear all; close all;

cd modeling_data
health_path = {'pr_0.1_H', 'pr_0.2_H', 'pr_0.3_H', 'pr_0.5_H', 'pr_1_H'};
patient_path = {'pr_0.1_P', 'pr_0.2_P', 'pr_0.3_P', 'pr_0.5_P', 'pr_1_P'};
index = {'01.csv', '02.csv', '03.csv', '04.csv', '05.csv', '06.csv',...
    '07.csv', '08.csv', '09.csv', '10.csv'};
for pr_idx = 1: 5
    % read health data
    for exp_idx = 1:10
        h_data_sub = strcat(health_path{pr_idx},'/',index{exp_idx});
        a_h = readtable(h_data_sub);
        t = table2array(a_h(9:176,1));
        p_wound_deris_h(:, pr_idx, exp_idx) = table2array(a_h(185:352,2));
        p_bacter_eaten_culm_h(:, pr_idx, exp_idx) = table2array(a_h(537:704,2));
    end
    % read patient data
    for exp_idx = 1:10
        p_data_sub = strcat(patient_path{pr_idx},'/',index{exp_idx});
        a_p = readtable(p_data_sub);
        t = table2array(a_h(9:176,1));
        p_wound_deris_p(:, pr_idx, exp_idx) = table2array(a_p(185:352,2));
        p_bacter_eaten_culm_p(:, pr_idx, exp_idx) = table2array(a_p(537:704,2));
    end    
end
pr = [0.1 0.2 0.3 0.5 1];
% Doing anova-test for different proliferation rate
disp('Doing t-test for different proliferation rate');
for pr_idx = 1: 5
    prolifer_rate = pr(pr_idx)
    x = p_wound_deris_h(:, pr_idx, :);
    y = p_wound_deris_p(:, pr_idx, :);
    [p,ci,stats] = anova1(x(:),y(:),'off');
    p
    [c,m] = multcompare(stats, 'ctype','bonferroni', 'display','on');
    p_new = anova1(m(:,1),m(:,2),'off')
end


% Doing anova-test for different proliferation rate
disp('Doing t-test for different proliferation rate')
for pr_idx = 1: 5
    prolifer_rate = pr(pr_idx)
    x = squeeze(p_bacter_eaten_culm_h(:, pr_idx, :));
    y = squeeze(p_bacter_eaten_culm_p(:, pr_idx, :));
    [p,ci,stats] = anova1(x(:),y(:),'off');
    p
    [c,m] = multcompare(stats, 'ctype','bonferroni', 'display','on');
    p_new = anova1(m(:,1),m(:,2),'off')
    
end