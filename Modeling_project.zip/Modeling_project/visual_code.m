clc; clear all; close all;

cd modeling_data
health_path = {'pr_0.1_H', 'pr_0.2_H', 'pr_0.3_H', 'pr_0.5_H', 'pr_1_H'};
patient_path = {'pr_0.1_P', 'pr_0.2_P', 'pr_0.3_P', 'pr_0.5_P', 'pr_1_P'};
index = {'01.csv', '02.csv', '03.csv', '04.csv', '05.csv', '06.csv',...
    '07.csv', '08.csv', '09.csv', '10.csv'};
for pr_idx = 1: 5
    % read health data
    for exp_idx = 1:10
        h_data_sub = strcat(health_path{pr_idx},'/',index{exp_idx});
        a_h = readtable(h_data_sub);
        t = table2array(a_h(9:176,1));
        numB_h(:, pr_idx, exp_idx) = table2array(a_h(9:176,2));
        p_wound_deris_h(:, pr_idx, exp_idx) = table2array(a_h(185:352,2));
        p_bacter_eaten_culm_h(:, pr_idx, exp_idx) = table2array(a_h(537:704,2));
    end
    % read patient data
    for exp_idx = 1:10
        p_data_sub = strcat(patient_path{pr_idx},'/',index{exp_idx});
        a_p = readtable(p_data_sub);
        t = table2array(a_h(9:176,1));
        numB_p(:, pr_idx, exp_idx) = table2array(a_p(9:176,2));
        p_wound_deris_p(:, pr_idx, exp_idx) = table2array(a_p(185:352,2));
        p_bacter_eaten_culm_p(:, pr_idx, exp_idx) = table2array(a_p(537:704,2));
    end    
end
%% plots 
tt = [1, 24:24:168];
% calculate std
err_num_B_h = std(numB_h(tt, :, :), 0, 3);
err_p_wound_deris_h = std(p_wound_deris_h(tt, :, :), 0, 3);
err_p_bacter_eaten_culm_h = std(p_bacter_eaten_culm_h(tt, :, :), 0 ,3);
err_num_B_p = std(numB_p(tt, :, :), 0, 3);
err_p_wound_deris_p = std(p_wound_deris_p(tt, :, :), 0, 3);
err_p_bacter_eaten_culm_p = std(p_bacter_eaten_culm_p(tt, :, :), 0 ,3);
% calculate mean 
mean_num_B_h = mean(numB_h(tt, :, :), 3);
mean_p_wound_deris_h = mean(p_wound_deris_h(tt, :, :), 3);
mean_p_bacter_eaten_culm_h = mean(p_bacter_eaten_culm_h(tt, :, :), 3);
mean_num_B_p = mean(numB_p(tt, :, :), 3);
mean_p_wound_deris_p = mean(p_wound_deris_p(tt, :, :), 3);
mean_p_bacter_eaten_culm_p = mean(p_bacter_eaten_culm_p(tt, :, :), 3);
% Figure 1
figure;
errorbar(tt, mean_num_B_h(:, 1), err_num_B_h(:,1),'r*-');hold on;
errorbar(tt, mean_num_B_h(:, 2), err_num_B_h(:,2),'bo-');hold on;
errorbar(tt, mean_num_B_h(:, 3), err_num_B_h(:,3),'kd-');hold on;
errorbar(tt, mean_num_B_h(:, 4), err_num_B_h(:,4),'gx-');hold on;
errorbar(tt, mean_num_B_h(:, 5), err_num_B_h(:,5),'ms-');hold on;
legend('Bacteria Prolif rate = 0.1','Bacteria Prolif rate = 0.2', 'Bacteria Prolif rate = 0.3', 'Bacteria Prolif rate = 0.5', 'Bacteria Prolif rate = 1');
xlabel('t/hour');ylabel('Number of bacteria');title('HEALTHY PERSON')
figure;
errorbar(tt, mean_num_B_p(:, 1), err_num_B_p(:,1),'r*-');hold on;
errorbar(tt, mean_num_B_p(:, 2), err_num_B_p(:,2),'bo-');hold on;
errorbar(tt, mean_num_B_p(:, 3), err_num_B_p(:,3),'kd-');hold on;
errorbar(tt, mean_num_B_p(:, 4), err_num_B_p(:,4),'gx-');hold on;
errorbar(tt, mean_num_B_p(:, 5), err_num_B_p(:,5),'ms-');hold on;
legend('Bacteria Prolif rate = 0.1','Bacteria Prolif rate = 0.2', 'Bacteria Prolif rate = 0.3', 'Bacteria Prolif rate = 0.5', 'Bacteria Prolif rate = 1');
xlabel('t/hour');ylabel('Number of bacteria');title('LEUKOPENIA PATIENT')


% Figure 2
figure;
h =bar(tt, mean_p_wound_deris_h(:, :));hold on;
% Get x centers; XOffset is undocumented
xCnt = (get(h(1),'XData') + cell2mat(get(h,'XOffset'))).'; 
errorbar(xCnt(:), mean_p_wound_deris_h(:), err_p_wound_deris_h(:), 'k', 'LineStyle','none')
xlabel('t(hour)');ylabel('Percentage of Wound Contain Debris(%)');title('HEALTHY PERSON')
legend('Bacteria Prolif rate = 0.1','Bacteria Prolif rate = 0.2', 'Bacteria Prolif rate = 0.3', 'Bacteria Prolif rate = 0.5', 'Bacteria Prolif rate = 1');
figure;
h = bar(tt, mean_p_wound_deris_p(:, :));hold on;
xCnt = (get(h(1),'XData') + cell2mat(get(h,'XOffset'))).'; 
errorbar(xCnt(:), mean_p_wound_deris_p(:), err_p_wound_deris_p(:), 'k', 'LineStyle','none')
legend('Bacteria Prolif rate = 0.1','Bacteria Prolif rate = 0.2', 'Bacteria Prolif rate = 0.3', 'Bacteria Prolif rate = 0.5', 'Bacteria Prolif rate = 1');
xlabel('t(hour)');ylabel('Percentage of Wound Contain Debris(%)');title('LEUKOPENIA PATIENT')

% Figure 3
figure;
h =bar(tt, mean_p_bacter_eaten_culm_h(:, :));hold on;
% Get x centers; XOffset is undocumented
xCnt = (get(h(1),'XData') + cell2mat(get(h,'XOffset'))).'; 
errorbar(xCnt(:), mean_p_bacter_eaten_culm_h(:), err_p_bacter_eaten_culm_h(:), 'k', 'LineStyle','none')
xlabel('t(hour)');ylabel('Percentage of Bacteria been Eaten(%)');title('HEALTHY PERSON')
legend('Bacteria Prolif rate = 0.1','Bacteria Prolif rate = 0.2', 'Bacteria Prolif rate = 0.3', 'Bacteria Prolif rate = 0.5', 'Bacteria Prolif rate = 1');
figure;
h = bar(tt, mean_p_bacter_eaten_culm_p(:, :));hold on;
xCnt = (get(h(1),'XData') + cell2mat(get(h,'XOffset'))).'; 
errorbar(xCnt(:), mean_p_bacter_eaten_culm_p(:), err_p_bacter_eaten_culm_p(:), 'k', 'LineStyle','none')
legend('Bacteria Prolif rate = 0.1','Bacteria Prolif rate = 0.2', 'Bacteria Prolif rate = 0.3', 'Bacteria Prolif rate = 0.5', 'Bacteria Prolif rate = 1');
xlabel('t(hour)');ylabel('Percentage of Bacteria been Eaten(%)');title('LEUKOPENIA PATIENT')